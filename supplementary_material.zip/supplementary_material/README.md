# Usage
run the binary in experiments/bin/  and provide arguments as follows:
`experiments/bin/simcjt m delta_p p_hat p_min pi l k s`
